import os
import argparse
import time
import h5py
import re
from threading import Thread
from tqdm import tqdm


def get_matching_files(pattern, directory):
    # 编译正则表达式模式
    regex = re.compile(pattern)
    # 获取目录中的所有文件和子目录
    files = os.listdir(directory)
    # 筛选符合正则表达式的文件
    matching_files = [
        f
        for f in files
        if os.path.isfile(os.path.join(directory, f)) and regex.match(f)
    ]
    return matching_files


def main(args):
    # print(args)
    dataset_dir = args["dataset_dir"]
    episode_idx = args["episode_idx"]
    camera_names = args["camera_names"]
    compress = not args["no_compress"]
    ignore_actions = args["ignore_actions"]
    ignore_images = args["ignore_images"]
    robots_num = args["robots_num"]
    can_bus_id = args["can_bus_id"]
    urdf_path = args["urdf_path"]
    task_name = args["task_name"]
    robot_name = args["robot_name"]
    DT = 1.0 / args["control_freq"]
    use_planning = args["use_planning"]
    wait_execute = args["wait_execute"]
    arm_velocity = args["arm_velocity"]
    vcan = "v" if args["virtual_can"] else ""
    ev_ts = args["replay_eval_results"]
    num_rollouts = args["num_rollouts"]
    auto_cycle = args["auto_cycle"]
    eef = args["end_effector"]
    # for base
    mobile_type = args["mobile_type"]
    base_prefix = args["base_prefix"]
    map_name = args["map_name"]
    track = not args[f"{base_prefix}_no_track"]
    # check
    assert camera_names is not None, "Camera names must be provided"
    assert robots_num == len(can_bus_id), "Can bus id num must be equal to robot num"

    """load dataset"""
    # construct dataset path
    if task_name != "":
        if dataset_dir == "AUTO":
            if ev_ts is None:  # replay demonstrations
                dataset_dir = f"{os.getcwd()}/demonstrations/hdf5/{task_name}"
                if mobile_type == "slantec_athena":
                    # now for base use raw data instead of hdf5 to replay
                    base_raw_dir = (
                        f"{os.getcwd()}/demonstrations/raw/{task_name}/{episode_idx}/"
                    )
                    base_raw_name = "base_poses.json"
                    base_raw_path = os.path.join(base_raw_dir, base_raw_name)
            else:  # replay evaluation results
                dataset_dir = f"{os.getcwd()}/eval_results/{task_name}/{ev_ts[0]}/"
                print(os.listdir(dataset_dir))

    if ev_ts is None:
        dataset_name = f"episode_{episode_idx}"
    else:
        if len(ev_ts) == 1:
            # auto find the first checkpoint matching the episode index
            dataset_name = get_matching_files(
                rf"^result_.*_{episode_idx}\.hdf5$", dataset_dir
            )[0].replace(".hdf5", "")
        else:
            ckpt_name = ev_ts[1]
            dataset_name = f"result_{ckpt_name}_{episode_idx}"

    dataset_path = os.path.join(dataset_dir, dataset_name + ".hdf5")
    if not os.path.isfile(dataset_path):
        print(f"Dataset does not exist at \n{dataset_path}\n")
        exit()
    # read data from hdf5
    with h5py.File(dataset_path, "r") as root:
        if not ignore_actions:
            actions = root["/action"][()]
            # if mobile_type == "slantec_athena":
            #     base_actions = root["/base_action"][()]
        if not ignore_images:
            import cv2

            images = {}
            for cam_name in camera_names:
                images[cam_name] = root[f"/observations/images/{cam_name}"][()]
                if compress:
                    # JPEG decompression
                    images_num = len(images[cam_name])
                    # print(images_num)
                    decompressed_list = [0] * images_num
                    for index, image in enumerate(images[cam_name]):
                        decompressed_list[index] = cv2.imdecode(image, 1)
                    images[cam_name] = decompressed_list

    """init robot"""
    if not ignore_actions:
        robots_list = []
        base_control = None
        if robot_name == "airbot_play":
            import airbot

            for index, id in enumerate(can_bus_id):
                robots_list.append(
                    airbot.create_agent(
                        "down", f"{vcan}can{id}", arm_velocity, eef[index]
                    )
                )
        elif "fake" in robot_name:

            class FakeRobot:
                def __init__(self, robot_name):
                    self.robot_name = robot_name

                def set_target_joint_q(
                    self, q, use_planning, arm_velocity, wait_execute
                ):
                    # print(f"{self.robot_name} set_target_joint_q: {q}")
                    pass

                def set_target_end(self, q, wait_execute):
                    # print(f"{self.robot_name} set_target_end: {q}")
                    pass

            for i in range(robots_num):
                robots_list.append(FakeRobot(f"fake_robot_{i}"))
        else:
            raise NotImplementedError(f"Unknown robot name: {robot_name}")

        if mobile_type == "slantec_athena":
            from airbase.airbase import ConfigAirBaseDemonstrator, AirBaseDemonstrator

            ConfigAirBaseDemonstrator.debug = True
            config = ConfigAirBaseDemonstrator(args, base_prefix)
            base_control = AirBaseDemonstrator(config)
            if map_name not in ["", "none", "None"]:
                print("Use map options.")
                base_control.map_option()
            base_control.show_status()
            # base_control.show_instruction()
            key_indexs = base_control.airbase.init_behavior(track, base_raw_path)
            print(key_indexs)
        elif "fake" in mobile_type:
            # TODO: add fake mobile
            pass

    if not ignore_images:
        # show multiple windows at the same time
        window_name = f"Camera {camera_names}"
        cv2.namedWindow(window_name, cv2.WINDOW_AUTOSIZE)
        images_num = len(list(images.values())[0])
        dt = int(DT * 1000)

    # replay
    arm_joints_num = 6  # TODO
    all_joints_num = arm_joints_num + 1
    start_time = time.time()
    for i in range(num_rollouts):
        # init robots and choose to start or exit
        if not ignore_actions:
            time.sleep(1)
            start_pose = list(actions[0])
            print(f"Move to start pose:{start_pose}...")
            action_dim = len(start_pose)
            print(f"Action dim: {action_dim}")
            if action_dim == 7 and robots_num > 1:
                start_pose *= robots_num
            print(f"Action dim: {len(start_pose)}")
            for index, robot in enumerate(robots_list):
                first = index * arm_joints_num
                last = first + arm_joints_num
                robot.set_target_joint_q(
                    start_pose[first:last], True, 0.2, wait_execute
                )
                robot.set_target_end(start_pose[last], wait_execute)
            if mobile_type == "slantec_athena":
                key = input(
                    "Press o and Enter to auto move the base to origin or m and Enter to manually move or just Enter to stay here."
                )
                if key == "o":
                    base_control.airbase.move_to_origin()
                elif key == "m":
                    base_control.airbase.lock(False)
                    input(
                        "Move the base to the desired position and press Enter to continue..."
                    )
                    base_control.airbase.lock(True)
            if not wait_execute and auto_cycle:
                time.sleep(3)
        print(f"Current replay rollout: {i}...")
        if (
            not auto_cycle
            and input("Press Enter to start replay or z and Enter to exit...") == "z"
        ):
            break

        # replay actions
        move_thread: Thread = None
        if not ignore_actions:
            print("Start replaying action...")
            if mobile_type == "slantec_athena":
                base_cnt = -1

                def move_base():
                    print(f"Move base at cnt: {base_cnt}...")
                    # print(f"Move base to {base_actions[base_cnt]} at cnt: {base_cnt}...")
                    base_control.airbase.replay_pose_once(base_cnt, True, True)

            for i in tqdm(range(len(actions))):
                # print(f"current step: {i+1}")
                if mobile_type == "slantec_athena":
                    if i > 0 and i in key_indexs:
                        if move_thread.is_alive():
                            print("Wait for the base move done...")
                            move_thread.join()
                target_action = list(actions[i])
                if len(target_action) == all_joints_num and robots_num > 1:
                    target_action *= robots_num
                for index, robot in enumerate(robots_list):
                    first = index * all_joints_num
                    last = first + all_joints_num - 1
                    robot.set_target_joint_q(
                        target_action[first:last], use_planning, arm_velocity, False
                    )
                    robot.set_target_end(target_action[last], False)
                if mobile_type == "slantec_athena":
                    if i in key_indexs[:-1]:
                        base_cnt += 1
                        move_thread = Thread(target=move_base, daemon=True)
                        move_thread.start()
                if wait_execute:
                    time.sleep(DT)
            print("Action replay finished.")

        # replay images
        if not ignore_images:
            print("Start replaying images...")
            for i in range(images_num):
                frames = [images[cam_name][i] for cam_name in camera_names]
                frame = cv2.hconcat(frames)
                cv2.imshow(window_name, frame)
                cv2.waitKey(dt)  # 40ms, 25fps
            print("Image replay finished.")
    end_time = time.time()
    print(f"Replay time: {end_time - start_time} s")
    print("exiting...")
    if not ignore_actions:
        for robot in robots_list:
            del robot

    if not ignore_images:
        cv2.destroyAllWindows()

    print("Replay all done.")


if __name__ == "__main__":

    base_ns = ["b", "base"]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-dd",
        "--dataset_dir",
        action="store",
        type=str,
        default="AUTO",
        help="Dataset directory containing hdf5 files of different tasks.",
    )
    parser.add_argument(
        "-tn",
        "--task_name",
        action="store",
        type=str,
        help="The task name of the data.",
        default="example_task",
    )
    parser.add_argument(
        "-ei",
        "--episode_idx",
        action="store",
        type=int,
        help="Data episode index to replay.",
        default=0,
    )
    parser.add_argument(
        "-cn",
        "--camera_names",
        nargs="+",
        default=("0",),
        help="Camera names used in the task.",
    )
    parser.add_argument(
        "-nc",
        "--no_compress",
        action="store_true",
        help="No compress images.",
    )
    parser.add_argument(
        "-ia",
        "--ignore_actions",
        action="store_true",
        help="Do not replay robot actions",
    )
    parser.add_argument(
        "-ii", "--ignore_images", action="store_true", help="Do not replay images"
    )
    parser.add_argument(
        "-rn",
        "--robots_num",
        action="store",
        type=int,
        default=1,
        help="Number of robots used in the task.",
    )
    parser.add_argument(
        "-can",
        "--can_bus_id",
        nargs="+",
        type=str,
        default=("0",),
        help="Can id used by the follower arms.",
    )
    parser.add_argument(
        "-up",
        "--urdf_path",
        action="store",
        type=str,
        default="",
        help="The urdf path for your robot.",
    )
    parser.add_argument(
        "-fq",
        "--control_freq",
        action="store",
        type=float,
        default=25.0,
        help="Control frequency of the task demonstration.",
    )
    parser.add_argument(
        "-rna",
        "--robot_name",
        action="store",
        type=str,
        default="airbot_play",
        help="Robot name used to control different robots using diffent control interfaces.",
    )
    parser.add_argument(
        "-vcan",
        "--virtual_can",
        action="store_true",
        help="Use virtual can so that real robots are not needed.",
    )
    parser.add_argument(
        "-av",
        "--arm_velocity",
        action="store",
        type=float,
        default=3.0,
        help="Arm velocity used to control the robot, default 0.0 means not using planning.",
    )
    parser.add_argument(
        "-p",
        "--use_planning",
        action="store_true",
        help="Use planning to control the robot.",
    )
    parser.add_argument(
        "-wt",
        "--wait_execute",
        action="store_true",
        help="Wait for the robot to execute the action, the control_freq arg will be ignored.",
    )
    parser.add_argument(
        "-ev",
        "--replay_eval_results",
        action="store",
        nargs="+",
        type=str,
        help="Specify the timestep and checkpoint name to replay the evaluation results.",
    )
    parser.add_argument(
        "-nr",
        "--num_rollouts",
        action="store",
        type=int,
        help="Maximum number of evaluation rollouts",
        default=20,
    )
    # for base
    parser.add_argument(
        "-mt",
        "--mobile_type",
        action="store",
        type=str,
        default="",  # "slantec_athena", "" means no mobile
        help='Mobile type used to specify which product will be used, such as slantec_athena;"" means no mobile.',
    )
    parser.add_argument(
        "-ip",
        "--ip",
        action="store",
        type=str,
        default="192.168.11.1",
        help="IP address of the mobile.",
    )
    parser.add_argument(
        "-mn",
        "--map_name",
        action="store",
        type=str,
        default="example_map",
        help="Map name used in the task.",
    )
    parser.add_argument(
        "-bs",
        f"--{base_ns[1]}_speed",
        action="store",
        type=str,
        default="high",
        help="Speed of the mobile.",
    )
    parser.add_argument(
        "-bnw",
        f"--{base_ns[1]}_not_wait_until_done",
        action="store_true",
        help="Not wait until the mobile is done.",
    )
    parser.add_argument(
        "-kt",
        f"--{base_ns[1]}_key_time",
        action="store",
        type=int,
        default=0,
        help="Key time to control the mobile.",
    )
    parser.add_argument(
        "-sf",
        f"--{base_ns[1]}_sleep_factor",
        action="store",
        type=int,
        default=1,
        help="Sleep factor to control the mobile.",
    )
    parser.add_argument(
        "-st",
        f"--{base_ns[1]}_sleep_time",
        action="store",
        type=int,
        default=0,
        help="Sleep time to control the mobile.",
    )
    parser.add_argument(
        "-nt",
        f"--{base_ns[1]}_no_track",
        action="store_true",
        help="Not track the mobile.",
    )
    parser.add_argument(
        "-rv",
        f"--{base_ns[1]}_record_velocity",
        action="store_true",
        help="Record the velocity of the mobile.",
    )
    parser.add_argument(
        "-bp",
        "--base_prefix",
        action="store",
        type=str,
        default=base_ns[1],
        help="The arg prefix for base. You should not change this unless change the default value at the same time.",
    )
    parser.add_argument(
        "-ac",
        "--auto_cycle",
        action="store_true",
        help="Auto cycle the replay.",
    )
    parser.add_argument(
        "-eef",
        "--end_effector",
        nargs="+",
        type=str,
        default=("gripper", "gripper"),
        help="End effectors used in the task.",
    )
    main(vars(parser.parse_args()))
