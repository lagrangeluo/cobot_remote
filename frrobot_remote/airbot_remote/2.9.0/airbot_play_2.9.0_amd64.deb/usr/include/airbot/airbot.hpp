#ifndef AIRBOT_HPP
#define AIRBOT_HPP
#define AIRBOT_VERSION "2.9.0"
#include "airbot/command/command_base.hpp"
#include "airbot/utils.hpp"
#include "airbot/modules/modules.hpp"
const std::string URDF_INSTALL_PATH = "/usr/share/airbot_models/";
#endif
