/**
 * This file is left empty on purpose. In CI this file is replaced with the actual generated documentation.
 */
#ifndef DOC
#define DOC(...) ""
#endif
