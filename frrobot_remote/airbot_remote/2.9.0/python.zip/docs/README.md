# docs submodule for python interface

Please modify the *.rst files according to your documentation needs.
